
disp("cos_t(10)");
result = cos_t(10)

disp("cosh_t(10)");
result = cosh_t(10)

disp("div_t(10)");
result = div_t(10)

disp("exp_t(10)");
result = exp_t(10)

disp("ln_t(10)");
result = ln_t(10)

disp("log_t(15,10)");
result = log_t(15,10)

disp("root_t(2,10)");
result = root_t(2,10)

disp("sin_t(10)");
result = sin_t(10)

disp("sinh_t(10)");
result = sinh_t(10)

disp("sqrt_t(10)");
result = sqrt_t(10)

disp("tan_t(10)");
result = tan_t(10)

disp("tanh_t(10)");
result = tanh_t(10)

disp("asin_t(pi/4)");
result = asin_t(pi/4)

disp("power_t(2,10)");
result = power_t(2,10)

disp("atan_t(1)");
result = atan_t(1)
